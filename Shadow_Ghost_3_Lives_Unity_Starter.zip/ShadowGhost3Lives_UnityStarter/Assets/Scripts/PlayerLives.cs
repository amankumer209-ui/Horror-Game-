using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerLives : MonoBehaviour
{
    public int startingLives = 3;
    public Text livesText;
    public GameObject gameOverPanel;
    public float hitCooldown = 2f;
    int lives;
    float lastHit = -999f;

    void Start()
    {
        lives = startingLives;
        RefreshUI();
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    public void TakeHit()
    {
        if (Time.time - lastHit < hitCooldown || lives <= 0) return;
        lastHit = Time.time;
        lives--;
        RefreshUI();
        if (lives <= 0)
        {
            if (gameOverPanel != null) gameOverPanel.SetActive(true);
            Time.timeScale = 0f;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    void RefreshUI()
    {
        if (livesText != null) livesText.text = "LIVES: " + lives + " / " + startingLives;
    }

    public void RestartLevel()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
