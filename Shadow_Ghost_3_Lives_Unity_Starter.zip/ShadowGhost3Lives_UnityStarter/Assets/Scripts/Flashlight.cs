using UnityEngine;

public class Flashlight : MonoBehaviour
{
    public Light torchLight;
    public KeyCode toggleKey = KeyCode.F;
    public bool startsOn = true;

    void Start()
    {
        if (torchLight != null) torchLight.enabled = startsOn;
    }

    void Update()
    {
        if (Input.GetKeyDown(toggleKey)) Toggle();
    }

    public void Toggle()
    {
        if (torchLight != null) torchLight.enabled = !torchLight.enabled;
    }
}
