using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 3.8f;
    public float runSpeed = 6.0f;
    public float gravity = -18f;
    public Transform cameraPivot;
    public float mouseSensitivity = 2f;
    public float touchLookSensitivity = 0.12f;

    [Header("Mobile UI (optional)")]
    public MobileJoystick joystick;
    public bool useTouchLook = true;

    CharacterController controller;
    Vector3 velocity;
    float pitch;
    Vector2 touchLookDelta;
    int lookFingerId = -1;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (cameraPivot == null && Camera.main != null) cameraPivot = Camera.main.transform;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        Vector2 mobileMove = joystick != null ? joystick.Value : Vector2.zero;
        if (mobileMove.sqrMagnitude > new Vector2(h, v).sqrMagnitude)
        {
            h = mobileMove.x;
            v = mobileMove.y;
        }

        bool running = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
        float speed = running ? runSpeed : moveSpeed;
        Vector3 move = (transform.right * h + transform.forward * v).normalized;
        controller.Move(move * speed * Time.deltaTime);

        if (controller.isGrounded && velocity.y < 0) velocity.y = -2f;
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

        HandleLook();
    }

    void HandleLook()
    {
        float mx = Input.GetAxis("Mouse X") * mouseSensitivity;
        float my = Input.GetAxis("Mouse Y") * mouseSensitivity;
        Vector2 look = new Vector2(mx, my);

        if (useTouchLook && Application.isMobilePlatform)
        {
            look += touchLookDelta * touchLookSensitivity;
            touchLookDelta = Vector2.zero;
        }

        transform.Rotate(Vector3.up * look.x);
        pitch = Mathf.Clamp(pitch - look.y, -78f, 78f);
        if (cameraPivot != null) cameraPivot.localEulerAngles = new Vector3(pitch, 0, 0);
    }

    // Connect a UI drag area to this method through an EventTrigger or a small pointer handler.
    public void AddTouchLookDelta(Vector2 delta) { touchLookDelta += delta; }
}
