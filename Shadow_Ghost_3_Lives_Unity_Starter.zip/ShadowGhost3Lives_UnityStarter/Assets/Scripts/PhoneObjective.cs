using UnityEngine;
using UnityEngine.UI;

public class PhoneObjective : MonoBehaviour
{
    public float interactDistance = 2.4f;
    public KeyCode interactKey = KeyCode.E;
    public Text objectiveText;
    public GameObject phoneObject;
    public GameObject winPanel;
    public string objective = "Find your lost phone";

    bool collected;
    Camera playerCamera;

    void Start()
    {
        playerCamera = Camera.main;
        if (objectiveText != null) objectiveText.text = "OBJECTIVE: " + objective;
        if (winPanel != null) winPanel.SetActive(false);
    }

    void Update()
    {
        if (collected || playerCamera == null || phoneObject == null) return;
        Ray ray = new Ray(playerCamera.transform.position, playerCamera.transform.forward);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, interactDistance) && hit.transform == phoneObject.transform)
        {
            if (objectiveText != null) objectiveText.text = "Press E / TAP INTERACT to pick up phone";
            if (Input.GetKeyDown(interactKey)) CollectPhone();
        }
        else if (objectiveText != null)
        {
            objectiveText.text = "OBJECTIVE: " + objective;
        }
    }

    public void CollectPhone()
    {
        if (collected) return;
        collected = true;
        phoneObject.SetActive(false);
        if (objectiveText != null) objectiveText.text = "PHONE FOUND! Now escape the school.";
        if (winPanel != null) winPanel.SetActive(true);
    }
}
