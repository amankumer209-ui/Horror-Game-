using UnityEngine;
using UnityEngine.EventSystems;

public class TouchLookArea : MonoBehaviour, IDragHandler
{
    public PlayerController player;
    public void OnDrag(PointerEventData eventData)
    {
        if (player != null) player.AddTouchLookDelta(eventData.delta);
    }
}
