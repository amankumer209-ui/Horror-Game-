using UnityEngine;

// Creates a simple fictional modern Indian school blockout from Unity primitives.
// Attach to an empty GameObject and press Play. Replace primitives with art assets later.
public class SchoolMapGenerator : MonoBehaviour
{
    public Material floorMaterial;
    public Material wallMaterial;
    public Material darkMaterial;
    public bool generateOnStart = true;

    const float RoomW = 8f;
    const float RoomD = 8f;
    const float WallH = 3.4f;
    const float WallT = 0.25f;

    void Start() { if (generateOnStart) Generate(); }

    [ContextMenu("Generate School Blockout")]
    public void Generate()
    {
        Transform old = transform.Find("GeneratedSchool");
        if (old != null)
        {
#if UNITY_EDITOR
            if (!Application.isPlaying) DestroyImmediate(old.gameObject);
            else Destroy(old.gameObject);
#else
            Destroy(old.gameObject);
#endif
        }

        GameObject root = new GameObject("GeneratedSchool");
        root.transform.SetParent(transform, false);

        // Main two-storey school footprint: central corridor with classrooms on both sides.
        BuildFloor(root.transform, "GroundFloor", 0f);
        BuildFloor(root.transform, "FirstFloor", 4.2f);
        BuildStaircase(root.transform);
        BuildPlayground(root.transform);
        BuildEntrance(root.transform);
    }

    void BuildFloor(Transform parent, string floorName, float y)
    {
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = floorName + "_Floor";
        floor.transform.SetParent(parent);
        floor.transform.position = new Vector3(0, y - 0.15f, 0);
        floor.transform.localScale = new Vector3(34, 0.3f, 22);
        Apply(floor, floorMaterial);

        // Corridor runs along X; rooms sit on the north and south sides.
        MakeWall(parent, floorName+"_BackWall", new Vector3(0,y+WallH/2,11), new Vector3(34,WallH,WallT));
        MakeWall(parent, floorName+"_FrontWall", new Vector3(0,y+WallH/2,-11), new Vector3(34,WallH,WallT));
        MakeWall(parent, floorName+"_LeftWall", new Vector3(-17,y+WallH/2,0), new Vector3(WallT,WallH,22));
        MakeWall(parent, floorName+"_RightWall", new Vector3(17,y+WallH/2,0), new Vector3(WallT,WallH,22));

        // Corridor side partitions and room labels are intentionally simple blockout geometry.
        for (int x = -12; x <= 12; x += 8)
        {
            MakeWall(parent, floorName+"_NorthPartition_"+x, new Vector3(x,y+WallH/2,6.1f), new Vector3(WallT,WallH,9.8f));
            MakeWall(parent, floorName+"_SouthPartition_"+x, new Vector3(x,y+WallH/2,-6.1f), new Vector3(WallT,WallH,9.8f));
        }

        // Corridor ceiling strips and lights.
        for (int x = -12; x <= 12; x += 6)
        {
            GameObject lightObj = new GameObject(floorName+"_CeilingLight_"+x);
            lightObj.transform.SetParent(parent);
            lightObj.transform.position = new Vector3(x, y + 3.15f, 0);
            Light l = lightObj.AddComponent<Light>();
            l.type = LightType.Point;
            l.range = 8;
            l.intensity = 0.7f;
        }
    }

    void BuildStaircase(Transform parent)
    {
        for (int i = 0; i < 10; i++)
        {
            GameObject step = GameObject.CreatePrimitive(PrimitiveType.Cube);
            step.name = "Stair_Step_" + i;
            step.transform.SetParent(parent);
            step.transform.position = new Vector3(14f, 0.2f + i * 0.42f, -7f + i * 0.55f);
            step.transform.localScale = new Vector3(3f, 0.35f, 0.8f);
            Apply(step, wallMaterial);
        }
    }

    void BuildPlayground(Transform parent)
    {
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Playground";
        ground.transform.SetParent(parent);
        ground.transform.position = new Vector3(0, -0.4f, 20f);
        ground.transform.localScale = new Vector3(42f, 0.5f, 18f);
        Apply(ground, darkMaterial);
    }

    void BuildEntrance(Transform parent)
    {
        GameObject sign = GameObject.CreatePrimitive(PrimitiveType.Cube);
        sign.name = "SHADOW_PUBLIC_SCHOOL_SIGN";
        sign.transform.SetParent(parent);
        sign.transform.position = new Vector3(0, 2f, -13f);
        sign.transform.localScale = new Vector3(8f, 1.2f, 0.3f);
        Apply(sign, darkMaterial);
    }

    void MakeWall(Transform parent, string n, Vector3 p, Vector3 s)
    {
        GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
        wall.name = n;
        wall.transform.SetParent(parent);
        wall.transform.position = p;
        wall.transform.localScale = s;
        Apply(wall, wallMaterial);
    }

    void Apply(GameObject obj, Material mat)
    {
        if (mat != null) obj.GetComponent<Renderer>().sharedMaterial = mat;
    }
}
