using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class ShadowGhostAI : MonoBehaviour
{
    public Transform player;
    public PlayerLives playerLives;
    public float sightDistance = 16f;
    [Range(10f, 180f)] public float sightAngle = 100f;
    public float hearingDistance = 11f;
    public float patrolRadius = 12f;
    public float attackDistance = 1.7f;
    public float surpriseIntervalMin = 18f;
    public float surpriseIntervalMax = 32f;
    public float chaseSpeed = 4.8f;
    public float patrolSpeed = 1.7f;

    NavMeshAgent agent;
    float nextSurpriseTime;
    float nextAttackTime;
    Vector3 home;

    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        home = transform.position;
        ScheduleSurprise();
    }

    void Update()
    {
        if (player == null) return;

        bool seen = CanSeePlayer();
        bool heard = IsPlayerMakingNoise() && Vector3.Distance(transform.position, player.position) <= hearingDistance;

        if (seen || heard)
        {
            agent.speed = chaseSpeed;
            agent.SetDestination(player.position);
        }
        else if (Time.time >= nextSurpriseTime)
        {
            TrySurpriseAppear();
            ScheduleSurprise();
        }
        else if (!agent.pathPending && agent.remainingDistance < 1.0f)
        {
            Patrol();
        }

        if (Vector3.Distance(transform.position, player.position) <= attackDistance &&
            Time.time >= nextAttackTime)
        {
            if (playerLives != null) playerLives.TakeHit();
            nextAttackTime = Time.time + 2.5f;
        }
    }

    bool CanSeePlayer()
    {
        Vector3 toPlayer = player.position - transform.position;
        if (toPlayer.magnitude > sightDistance) return false;
        if (Vector3.Angle(transform.forward, toPlayer) > sightAngle * 0.5f) return false;

        RaycastHit hit;
        Vector3 origin = transform.position + Vector3.up * 1.5f;
        if (Physics.Raycast(origin, (player.position + Vector3.up - origin).normalized, out hit, sightDistance))
            return hit.transform == player || hit.transform.IsChildOf(player);
        return false;
    }

    bool IsPlayerMakingNoise()
    {
        CharacterController cc = player.GetComponent<CharacterController>();
        if (cc == null) return false;
        // Running with Shift is the initial prototype's noise signal.
        return Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
    }

    void Patrol()
    {
        agent.speed = patrolSpeed;
        Vector3 random = home + Random.insideUnitSphere * patrolRadius;
        NavMeshHit hit;
        if (NavMesh.SamplePosition(random, out hit, patrolRadius, NavMesh.AllAreas))
            agent.SetDestination(hit.position);
    }

    void TrySurpriseAppear()
    {
        if (Vector3.Distance(transform.position, player.position) < 7f) return;
        Vector3 behind = player.position - player.forward * Random.Range(5f, 9f);
        NavMeshHit hit;
        if (NavMesh.SamplePosition(behind, out hit, 5f, NavMesh.AllAreas))
        {
            agent.Warp(hit.position);
            transform.LookAt(player.position);
        }
    }

    void ScheduleSurprise()
    {
        nextSurpriseTime = Time.time + Random.Range(surpriseIntervalMin, surpriseIntervalMax);
    }
}
