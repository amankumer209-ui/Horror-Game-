# SHADOW GHOST: 3 LIVES — Unity Starter Kit

यह एक **प्रारंभिक playable prototype scaffold** है, पूरा finished game या compiled APK नहीं।
इसे Unity में खोलकर scene setup और Android/PC build किया जा सकता है।

## अनुशंसित Unity
- Unity 2022.3 LTS या Unity 6 LTS
- 3D (Built-in Render Pipeline) project
- Android Build Support (SDK, NDK, OpenJDK) Android APK के लिए

## शामिल सिस्टम
- First-person CharacterController movement
- Keyboard/mouse controls और optional mobile joystick/touch-look scripts
- Flashlight toggle
- 3 lives और Game Over / Restart logic
- Shadow Ghost: sight chase, running-noise detection, surprise reposition, patrol
- Lost phone objective
- Fictional modern two-storey school blockout generator

## Unity में शुरू करने के चरण
1. Unity Hub में नया **3D Core** प्रोजेक्ट बनाएं।
2. इस ZIP के `Assets/Scripts` फ़ोल्डर को अपने प्रोजेक्ट के `Assets` में कॉपी करें।
3. Scene में Plane/Cube से test floor या `SchoolMapGenerator` वाला Empty GameObject बनाएं।
4. `SchoolMapGenerator` script जोड़ें और Play दबाएं। यह greybox school layout बनाएगा।
5. Player के लिए Capsule बनाएं, उसमें `CharacterController` और `PlayerController` जोड़ें।
6. Player के अंदर Camera बनाएं; उसे `cameraPivot` में assign करें। Camera का tag `MainCamera` रखें।
7. Player पर `PlayerLives` जोड़ें और UI Text / Game Over panel assign करें।
8. Ghost के लिए काले रंग का Capsule या custom mesh बनाएं; `NavMeshAgent` और `ShadowGhostAI` जोड़ें।
9. Player Transform और PlayerLives को Ghost के fields में assign करें।
10. स्कूल के चलने योग्य floor पर Navigation Static सेट करें और AI Navigation package/Navigation window से NavMesh bake करें। Ghost को baked NavMesh पर रखें।
11. Phone mesh बनाकर collider दें; `PhoneObjective.phoneObject` में assign करें। `MainCamera` से फोन पर raycast होगा।
12. Flashlight के लिए Camera का child Spot Light बनाएं और `Flashlight` script में assign करें।

## Controls
- PC: WASD / Arrow keys = Move, Mouse = Look, Shift = Run, F = Flashlight, E = Phone interact
- Mobile: Canvas में joystick background + handle बनाकर `MobileJoystick` जोड़ें; right-side transparent UI panel पर `TouchLookArea` जोड़ें और Player assign करें। Flashlight/Interact के लिए UI Buttons से `Flashlight.Toggle()` और `PhoneObjective.CollectPhone()` call करें।

## महत्वपूर्ण prototype notes
- यह अभी greybox है: स्कूल का layout काल्पनिक है और primitive geometry से बनता है।
- Surprise behavior अभी ghost को खिलाड़ी के पीछे NavMesh पर reposition करता है; इसे बाद में scripted scare sequences से बेहतर किया जा सकता है।
- Running-noise detection इस prototype में Shift key से जुड़ा है। मोबाइल के लिए run button/state जोड़ना होगा।
- Phone pickup UI interaction के लिए PC पर E काम करता है; मोबाइल UI Button को `CollectPhone()` से जोड़ें।
- वास्तविक APK बनाने से पहले NavMesh, UI, lighting, audio, scene references, Android orientation और performance की जाँच आवश्यक है।
- Android APK compile करने के लिए Unity Editor और Android Build Support इस प्रोजेक्ट को खोलने वाले कंप्यूटर पर स्थापित होना चाहिए।
